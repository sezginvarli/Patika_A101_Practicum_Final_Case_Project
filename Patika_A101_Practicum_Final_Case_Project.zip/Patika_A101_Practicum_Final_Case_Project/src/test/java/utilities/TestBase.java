package utilities;

public class TestBase {
}
