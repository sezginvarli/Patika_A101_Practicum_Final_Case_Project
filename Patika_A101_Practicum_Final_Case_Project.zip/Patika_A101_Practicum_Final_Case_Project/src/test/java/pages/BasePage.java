package pages;

public class BasePage {

}
